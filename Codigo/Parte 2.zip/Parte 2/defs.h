/******************************************************************************
 *
 * File Name: defs.h
 *	      (c) 2010 AED
 * Authors:    AED Team
 * Last modified: ACR 2010-03-17
 * Revision:  v2.1
 *
 * COMMENTS
 *
 *****************************************************************************/

#ifndef _DEFS_H
#define _DEFS_H


#define DIM_MAX_PALAVRA 200

#define Item void*

#endif
